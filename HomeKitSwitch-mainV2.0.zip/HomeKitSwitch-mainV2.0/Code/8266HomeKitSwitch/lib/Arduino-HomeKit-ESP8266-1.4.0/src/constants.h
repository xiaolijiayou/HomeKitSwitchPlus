#pragma once

#define DEVICE_ID_SIZE 36
#define ACCESSORY_ID_SIZE   17
